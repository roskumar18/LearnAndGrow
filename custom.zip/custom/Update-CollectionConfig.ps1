param(
        [Parameter(Mandatory)]
        [string]$SolrEndpoint,

        [Parameter(Mandatory)]
        [string]$SolrCollectionName,

        [Parameter(Mandatory)]
        [string]$SolrCollectionConfig
)





        Write-Host "Updating collection $SolrCollectionName with config $SolrCollectionConfig"


        $url = "$SolrEndpoint/admin/collections?action=MODIFYCOLLECTION&collection=$solrCollectionName&collection.configName=$SolrCollectionConfig"
        Invoke-WebRequest -UseBasicParsing -Uri $url | Out-Null
   
